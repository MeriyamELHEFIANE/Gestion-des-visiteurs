<?php


//isset() vérifie si une variable est définie"renvoie TRUE si la variable existe et n'est pas NULL"
if (isset($_POST['submit'])) {//si la méthode d’envoi du formulaire est POST
    //extract()convertit les clés de tableau en noms de variable et les valeurs de tableau en valeur de variable
    extract($_POST);//si la méthode d’envoi du formulaire est POST
    if(isset($CIN) && isset($NOM) && isset($PRENOM) && isset($TELEPHONE) && isset($VILLE) && isset($ADRESSE) && isset($TYPE_DE_VISITEUR) && $ENTREPRISE){
        //connexion à la base de donnée
        //mysqli_connect fonction ouvre une nouvelle connexion au serveur MySQL.
        $conn =mysqli_connect('localhost','root','','gestion_des_visiteurs');
        //requête d'ajout
        //Exécute une requête sur la base de données
        $req=mysqli_query($conn , "INSERT INTO visiteur VALUES ('','$CIN','$NOM','$PRENOM','$TELEPHONE','$VILLE','$ADRESSE','$TYPE_DE_VISITEUR','$ENTREPRISE')");
        if($req){//si la requête a été effectuée avec succès , on fait une redirection
            header("location: ajoutervisite.php");
        }else {//si non
            $message = "visiteur non ajouté";
        }
   }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css?v=<?php echo time(); ?>">
    <title>GESTION DES VISITEURS</title>
</head>
<body>
<a href="acceuil.php"><img src="home.jpg" width="50" height="50"></a>
<form action="index.php" class="box" method="post">
      <h1>GESTION DES VISITEURS</h1>
     <div class="row">
        <input type="text" name="CIN" placeholder="CIN" >
        <input type="text" name="NOM" placeholder="NOM">
     </div>
     <div class="row">
        <input type="text" name="PRENOM" placeholder="PRENOM">
        <input type="text" name="TELEPHONE" placeholder="+212">
     </div>
     <div class="row">
     <input type="text" list="VILLE" name="VILLE" placeholder="VILLE">
    <datalist id="VILLE">
      <option value="Agadir">
      <option value="Ait melloul">
      <option value="Biougra">
      <option value="Casablanca">
      <option value="Chtouka ait baha">
      <option value="El jadida">
      <option value="Essouira">
      <option value="Guelmim">
      <option value="Inzgane">
      <option value="Marrakech">
      <option value="Massa">
      <option value="Rabat">
      <option value="Safi">
      <option value="Sidi ifni">
      <option value="Tanger">
      <option value="Taroudant">
      <option value="Tata">
      <option value="Tiznit">
      <option value="Zagora">
    </datalist> 
      <input type="text" name="ADRESSE" placeholder="ADRESSE">
     </div>

     <div class="row">
     <input type="text" list="TYPE_DE_VISITEUR" name="TYPE_DE_VISITEUR" placeholder="TYPE DE VISITEUR">
    <datalist id="TYPE_DE_VISITEUR">
        <option value="ADHERENT">
        <option value="ASSOCIATIONS PROFESSIONNELLES">
        <option value="AUTO-ENTREPRENEUR">
        <option value="CHEF D'ENTREPRISE">
        <option value="COMMERCANT">
        <option value="CREATEUR D'ENTREPRISE">
        <option value="ETUDIANT">
        <option value="FOURNISSEUR/PRESTATAIRE">
        <option value="INVESTISSEUR">
        <option value="MEMBRES">
        <option value="PARTENAIRES">
        <option value="PRESSE">
        <option value="AUTRES">
    </datalist> 

      <input type="text" name="ENTREPRISE" placeholder="ENTREPRISE">
     </div>
    <input type=submit value="ENVOYER" name=submit >
    <a href="ajoutervisite.php"><img src="images.png" width="40" height="40"></a>
</form>
</body>
</html>