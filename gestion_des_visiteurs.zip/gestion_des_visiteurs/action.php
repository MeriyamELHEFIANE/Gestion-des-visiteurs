<?php
//isset() vérifie si une variable est définie"renvoie TRUE si la variable existe et n'est pas NULL"
if (isset($_POST['submit'])) {//si la méthode d’envoi du formulaire est POST
    //extract()convertit les clés de tableau en noms de variable et les valeurs de tableau en valeur de variable
    extract($_POST);//si la méthode d’envoi du formulaire est POST
    if(isset($id) && isset($PRESTATION) && isset($OBJET_DE_VISITE) && isset($PERS_A_CONTACTER) && isset($DEPARTEMENT) && isset($SERVICE) && isset($DATE_VST) && isset($HEURE_VST) && $OBSERVATION){
        //connexion à la base de donnée
       //mysqli_connect fonction ouvre une nouvelle connexion au serveur MySQL.
        $conn =mysqli_connect('localhost','root','','gestion_des_visiteurs');
        //requête d'ajout
        //Exécute une requête sur la base de données
       $req= mysqli_query($conn , "INSERT INTO visite VALUES ('','$id','$PRESTATION','$OBJET_DE_VISITE','$PERS_A_CONTACTER','$DEPARTEMENT','$SERVICE','$DATE_VST','$HEURE_VST','$OBSERVATION')");
        if($req){//si la requête a été effectuée avec succès , on fait une redirection
            header("location: index.php");
        }else {//si non
            $message = "visite non ajouté";
        }
   }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css?v=<?php echo time(); ?>">
    <title>FICHE VISITE</title>
</head>
<body>
<a href="acceuil.php"><img src="home.jpg" width="50" height="50"></a>
<form action="action.php" class="box" method="post">
      <h1>FICHE VISITE</h1>
     <div class="row">
     <input type="text" list="PRESTATION" name="PRESTATION" placeholder="PRESTATION">
    <datalist id="PRESTATION">
            <option value="ACCOMPAGENEMENT">
            <option value="BURREAU D'ORDRE">
            <option value="COMPTAILITE">
            <option value="DEMANDE D'INFORMATIONS">
            <option value="DIRECTEUR">
            <option value="DOCUMENTS ADMINIDTRATIFS">
            <option value="ESPACES/SALLES">
            <option value="EVENMENTS">
            <option value="FORMATION">
            <option value="GUICHETS">
            <option value="PERSONNEL">
            <option value="PRESIDENT">
            <option value="PRESTATAIRE EXTERNE">
            <option value="RECLAMATIONS">
            <option value="REUNIONS">
            <option value="VICE PRESIDENT">
    </datalist>
     <input type="text" list="OBJET_DE_VISITE" name="OBJET_DE_VISITE" placeholder="OBJET DE VISITE">
    <datalist id="OBJET_DE_VISITE">
            <option value="ATTESTATION + CARTE                   |F1">
            <option value="ATTESTATION DE SATGE                  |F1">
            <option value="ATTESTATION PROFFESSIONNELLE |F1">
            <option value="CARTE ADHESION                           |F1">
            <option value="CERTEFICAT D'ORIGINE                   |F1">
    </datalist>
    
     </div>
     <div class="row">
     <input type="text" list="PERS_A_CONTACTER" name="PERS_A_CONTACTER" placeholder="PERSONNE A CONTACTER">
    <datalist id="PERS_A_CONTACTER">
            <option value="AANIBAR Sofia">
            <option value="ACHENGLI Karim">
            <option value="AHECHMOUD Bachir">
            <option value="ALLILECH Roukia">
            <option value="AOUBID Mhand ">
            <option value="AQEL Rabya">
            <option value="ASSIS Fatima">
            <option value="BAKARI Jmiaa">
            <option value="BEN CHRIF Safae">
            <option value="BENHAMOU Yassine">
            <option value="BENNANI Rabia">
            <option value="BOUDLAL Lamia">
            <option value="DAMNATI Ali">
            <option value="DIKER Mohamed">
            <option value="DOR Said">
            <option value="EL-MESKY Mustapha">
            <option value="EL-MOUDEN Mohamed">
            <option value="EL-YATRIBI Abdelhani">
            <option value="ELKHADRY Hamid">
            <option value="GASSMI Abdelouahab">
            <option value="JALANI Soumia">
            <option value="KESSISSE Saadia">
            <option value="KHALDI Said">
            <option value="LHASSOUIA Naima">
            <option value="MANOUZ Lahcen">
            <option value="MOTIA Mohamed">
            <option value="MOUNADI Hassan">
            <option value="MRABET Soumia">
            <option value="NACIRI Hicham">
            <option value="NIMKLAL Hamid">
            <option value="OUMCHICH Fouzia">
            <option value="RAMY Abderahim">
            <option value="ZOUKY Najat">
    </datalist>
    <input type="text" list="DEPARTEMENT" name="DEPARTEMENT" placeholder="DEPARTEMENT" >
    <datalist id="DEPARTEMENT">
            <option value="Département services aux ressortissants ">
            <option value="Département Appui et Promotion">
            <option value="Département Stratégie et Partenariat">
            <option value="Département Administractif,Financier et Suivi de Gestion ">
    </datalist>
     </div>
     <div class="row"> 
     <input type="text" list="SERVICE" name="SERVICE" placeholder="SERVICE">
     <datalist id="SERVICE">
            <option value="Service Information et Communication">
            <option value="Service Prestations de proximité">
            <option value="Service Formation et Networking">
            <option value="Service Promotion et Développement">
            <option value="Service Partenariat et Diplomatie économique">
            <option value="Service Stratégie et Relations institutionnelles">
            <option value="Service Ressources Financieres et système d'information">
    </datalist>
  <input type="date" id="DATE_VST" name="DATE_VST">

  
     </div>

<div class="row">
     <input type="time" id="HEURE_VST" name="HEURE_VST" >
     <input type="text" id="OBSERVATION" name="OBSERVATION" placeholder="OBSERVATION">
 </div>
 <input type=text hidden value=<?php echo $_GET['id']; ?> name=id><!--si la méthode d’envoi du formulaire est GET-->
 
 <!--
     <span>SATISFAIT</span><br>
     <label for="oui">oui</label>
     <input type="checkbox"  name="SATISFAIT" value="oui" >
     <label for="non">non</label>
     <input type="checkbox"  name="SATISFAIT" value="non">
     <label for="non">non</label>
     <input type="radio" id="non" name="SATISFAIT" value="non" >-->

<input type=submit value="ENVOYER" name=submit>
</form>
</body>
</html>