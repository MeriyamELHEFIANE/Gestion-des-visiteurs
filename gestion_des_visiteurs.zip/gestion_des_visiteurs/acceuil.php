
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>gestion des visiteurs</title>
    <link rel="stylesheet" href="acceuil.css">
</head>
<body>
<?php
?>
 
    <div class="banner">
        <div class="content">
            <h1>WELCOME</h1>
            <!--définit une division ou une section dans un document HTML-->
          <div>
            <!--<span>pour regrouper des éléments en ligne dans un document-->
            <a href="index.php"><button type="button"><span></span>AJOUTER LE VISITEUR</button></a>
            <a href="recherche.php"><button type="button"><span></span>LA RECHERCHE</button></a>
          </div>
        </div>
    </div>
</body>
</html>