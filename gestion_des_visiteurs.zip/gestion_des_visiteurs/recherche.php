<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>rechercher</title>
</head>

<body>
<a href="acceuil.php"><img src="home.jpg" width="65" height="60"></a>


    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card mt-4">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-7">

                                <form action="" method="GET">
                                    <div class="input-group mb-3">
                                        <input type="text" name="search" required value="<?php if(isset($_GET['search'])){echo $_GET['search']; } ?>" class="form-control" placeholder="enter le cin ou le nom ou le prenom..">
                                        <button type="submit" class="btn btn-primary">RECHERCHER</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-12">
                <div class="card mt-4">
                    <div class="card-body">
                        <table class="table table-bordered">
                            <thead>
                                <tr><!--tr Ligne de tableau -->
                                    <th>id</th><!--th Cellule d'en-tête-->
                                    <th>CIN</th>
                                    <th>NOM</th>
                                    <th>PRENOM</th>
                                    <th>TELEPHONE</th>
                                    <th>VILLE</th>
                                    <th>ADRESSE</th>
                                    <th>TYPE_DE_VISITEUR</th>
                                    <th>ENTREPRISE</th>
                                    <th>PRESTATION</th>
                                    <th>OBJET_DE_VISITE</th>
                                    <th>PERS_A_CONTACTER</th>
                                    <th>DEPARTEMENT</th>
                                    <th>SERVICE</th>
                                    <th>DATE_VST</th>
                                    <th>HEURE_VST</th>
                                    <th>OBSERVATION</th>
                                    <th>supprimer</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                    $con = mysqli_connect("localhost","root","","gestion_des_visiteurs");
                                    //isset() vérifie si une variable est définie"renvoie TRUE si la variable existe et n'est pas NULL"
                                    if(isset($_GET['search']))
                                    {
                                        $filtervalues = $_GET['search'];
                                        $query = "SELECT *FROM visiteur NATURAL JOIN visite WHERE CONCAT(CIN,NOM,PRENOM) LIKE '%$filtervalues%'; " ;
                                        //Exécute une requête sur la base de données
                                        $query_run = mysqli_query($con, $query);
                                        //mysqli_num_rows qui retourne simplement le nombre de lignes d'un résultat.
                                        if(mysqli_num_rows($query_run) > 0)
                                        {
                                            //parcourir les tableaux et les objets à la place de la boucle for ou de la boucle while.
                                            foreach($query_run as $items)
                                            {
                                                ?>
                                                <tr>
                                                    <td><?= $items['id']; ?></td><!--td Cellule-->
                                                    <td><?= $items['CIN']; ?></td>
                                                    <td><?= $items['NOM']; ?></td>
                                                    <td><?= $items['PRENOM']; ?></td>
                                                    <td><?= $items['TELEPHONE']; ?></td>
                                                    <td><?= $items['VILLE']; ?></td>
                                                    <td><?= $items['ADRESSE']; ?></td>
                                                    <td><?= $items['TYPE_DE_VISITEUR']; ?></td>
                                                    <td><?= $items['ENTREPRISE']; ?></td>
                                                    <td><?= $items['PRESTATION']; ?></td>
                                                    <td><?= $items['OBJET_DE_VISITE']; ?></td>
                                                    <td><?= $items['PERS_A_CONTACTER']; ?></td>
                                                    <td><?= $items['DEPARTEMENT']; ?></td>
                                                    <td><?= $items['SERVICE']; ?></td>
                                                    <td><?= $items['DATE_VST']; ?></td>
                                                    <td><?= $items['HEURE_VST']; ?></td>
                                                    <td><?= $items['OBSERVATION']; ?></td>
                                                    <td><a href="sup.php?id=<?=$items['id']?>"><img src="trash.png" width="70" height="55"></a></td>
                                                </tr>
                                                <?php
                                            }
                                        }
                                        else
                                        {
                                            ?>
                                                <tr>
                                                    <td colspan="17">Le visiteur n'existe pas </td>
                                                </tr>
                                            <?php
                                        }
                                    }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>