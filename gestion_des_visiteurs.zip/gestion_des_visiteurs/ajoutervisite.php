
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion DES VISITEURS</title>
    <link rel="stylesheet" href="ajoutervisite.css">
</head>
<body>
    <!--définit une division ou une section dans un document HTML-->
    <div class="container">
        <a href="index.php" class="Btn_add"><img src="retlogo.png"  ></a>
        
        <table>
            <tr id="items" >
                <th>CIN</th>
                <th>NOM</th>
                <th>PRENOM</th>
                <th>TELEPHONE</th>
                <th>VILLE</th>
                <th>ADRESSE</th>
                <th>TYPE_DE_VISITEUR</th>
                <th>ENTREPRISE</th>
                <th>Supprimer</th>
                <th>ajouter visite</th>
            </tr>
            <?php 
            //mysqli_connect fonction ouvre une nouvelle connexion au serveur MySQL.
              $conn =mysqli_connect('localhost','root','','gestion_des_visiteurs');
              if(!$conn){
              echo "error"; 
              }
              //Exécute une requête sur la base de données
                $req = mysqli_query($conn , "SELECT * FROM visiteur order by id desc");
                //mysqli_num_rows qui retourne simplement le nombre de lignes d'un résultat.
                if(mysqli_num_rows($req) == 0){
                    echo "Il n'y a pas encore de visiteur ajouter !" ;
                    
                }else {
                    //mysqli_fech_assoc Récupère une ligne de résultat sous forme de tableau associatif
                    while($row=mysqli_fetch_assoc($req)){
                        ?>
                        <tr>
                            <td><?=$row['CIN']?></td>
                            <td><?=$row['NOM']?></td>
                            <td><?=$row['PRENOM']?></td>
                            <td><?=$row['TELEPHONE']?></td>
                            <td><?=$row['VILLE']?></td>
                            <td><?=$row['ADRESSE']?></td>
                            <td><?=$row['TYPE_DE_VISITEUR']?></td>
                            <td><?=$row['ENTREPRISE']?></td>
                            <td><a href="supprimer.php?CIN=<?=$row['CIN']?>"><img src="trashlogo.jpg"></a></td>
                            <td><a href="action.php?id=<?=$row['id']?>"><img src="plus.png"></a></td>
                        </tr>
                        <?php
                    }
                    
                }
            ?>
      
         
        </table>
   
   
   
   
    </div>
</body>
</html>