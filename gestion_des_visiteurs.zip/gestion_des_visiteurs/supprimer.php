<?php
//mysqli_connect fonction ouvre une nouvelle connexion au serveur MySQL.
$conn =mysqli_connect('localhost','root','','gestion_des_visiteurs');
if(!$conn){
  echo "error"; 
}
  //récupération de l'id dans le lien
  $filtervalues = $_GET['CIN'];
  //requête de suppression
  $query = "DELETE FROM visiteur WHERE CONCAT(CIN,NOM,PRENOM) LIKE '%$filtervalues%' ";
  //Exécute une requête sur la base de données
  $query_run = mysqli_query($conn, $query);
  //redirection vers la page index.php
  header("Location:ajoutervisite.php");
?>