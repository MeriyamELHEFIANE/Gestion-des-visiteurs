<?php
//mysqli_connect fonction ouvre une nouvelle connexion au serveur MySQL.
$conn =mysqli_connect('localhost','root','','gestion_des_visiteurs');
if(!$conn){
  echo "error"; 
}
  //récupération de l'id dans le lien
  $id = $_GET['id'];
  //requête de suppression
  //Exécute une requête sur la base de données
  $req= mysqli_query($conn, 'DELETE o,od from visiteur o join visite od on o.id=od.id where o.id="'.$id.'"');
  //redirection vers la page index.php
  header("Location:recherche.php");
?>
